from django.apps import AppConfig


class BlogarticlesConfig(AppConfig):
    name = 'blogArticles'
